import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-polul-nord',
  templateUrl: './polul-nord.component.html',
  styleUrls: ['./polul-nord.component.scss']
})
export class PolulNordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
