import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amerca-de-nord',
  templateUrl: './amerca-de-nord.component.html',
  styleUrls: ['./amerca-de-nord.component.scss']
})
export class AmercaDeNordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
