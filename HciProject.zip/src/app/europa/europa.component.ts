import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-europa',
  templateUrl: './europa.component.html',
  styleUrls: ['./europa.component.scss']
})
export class EuropaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
