import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-antarctida',
  templateUrl: './antarctida.component.html',
  styleUrls: ['./antarctida.component.scss']
})
export class AntarctidaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
