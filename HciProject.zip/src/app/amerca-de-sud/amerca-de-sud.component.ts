import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amerca-de-sud',
  templateUrl: './amerca-de-sud.component.html',
  styleUrls: ['./amerca-de-sud.component.scss']
})
export class AmercaDeSudComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
